from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from app import get_db_connection
from psycopg.rows import dict_row
from datetime import datetime

appointments_bp = Blueprint("appointments", __name__, url_prefix="/appointments")

def generate_appointment_code(cursor):
    cursor.execute("SELECT COALESCE(MAX(appointment_id), 0) + 1 FROM public.appointments;")
    next_id = cursor.fetchone()[0]
    return f"APT-{next_id:04d}"

@appointments_bp.route("/", methods=["GET"])
@login_required
def index():
    status_filter = request.args.get("status", "").strip()
    search = request.args.get("q", "").strip()
    appointments = []
    error = None

    try:
        with get_db_connection() as conn:
            with conn.cursor(row_factory=dict_row) as cur:
                base_query = """
                    SELECT 
                        a.appointment_id,
                        a.appointment_code,
                        a.appointment_date,
                        a.reason,
                        a.status,
                        a.notes,
                        p.patient_id,
                        p.patient_code,
                        CONCAT(p.first_name, ' ', p.last_name) AS patient_name,
                        p.phone AS patient_phone,
                        d.doctor_id,
                        d.doctor_name,
                        d.specialization
                    FROM public.appointments a
                    JOIN public.patients p ON a.patient_id = p.patient_id
                    JOIN public.doctors d ON a.doctor_id = d.doctor_id
                    WHERE 1=1
                """
                params = []

                if status_filter:
                    base_query += " AND a.status = %s"
                    params.append(status_filter)

                if search:
                    base_query += """ AND (
                        a.appointment_code ILIKE %s OR
                        CONCAT(p.first_name, ' ', p.last_name) ILIKE %s OR
                        d.doctor_name ILIKE %s OR
                        a.reason ILIKE %s
                    )"""
                    pattern = f"%{search}%"
                    params.extend([pattern, pattern, pattern, pattern])

                base_query += " ORDER BY a.appointment_date DESC;"

                cur.execute(base_query, tuple(params))
                appointments = cur.fetchall()

    except Exception as e:
        error = f"Database Error: {str(e)}"

    stats = {
        "total": len(appointments),
        "scheduled": sum(1 for a in appointments if a.get("status") == "Scheduled"),
        "completed": sum(1 for a in appointments if a.get("status") == "Completed"),
        "cancelled": sum(1 for a in appointments if a.get("status") == "Cancelled")
    }

    return render_template(
        "appointments/index.html",
        appointments=appointments,
        status_filter=status_filter,
        search=search,
        stats=stats,
        error=error
    )

@appointments_bp.route("/book", methods=["GET", "POST"])
@login_required
def book():
    try:
        with get_db_connection() as conn:
            with conn.cursor(row_factory=dict_row) as cur:
                cur.execute("SELECT patient_id, patient_code, first_name, last_name, phone FROM public.patients WHERE is_active = TRUE ORDER BY first_name ASC;")
                patients = cur.fetchall()

                cur.execute("SELECT doctor_id, doctor_name, specialization, consultation_fee FROM public.doctors WHERE is_active = TRUE ORDER BY doctor_name ASC;")
                doctors = cur.fetchall()

        if request.method == "POST":
            patient_id = request.form.get("patient_id")
            doctor_id = request.form.get("doctor_id")
            appointment_date_str = request.form.get("appointment_date")
            reason = request.form.get("reason", "").strip()
            notes = request.form.get("notes", "").strip()
            status = request.form.get("status", "Scheduled")
            created_by = getattr(current_user, "user_id", None)

            if not patient_id or not doctor_id or not appointment_date_str:
                flash("Patient, Doctor and Date/Time are required!", "danger")
                return render_template("appointments/form.html", patients=patients, doctors=doctors, appointment={}, action="Book")

            appointment_date = datetime.fromisoformat(appointment_date_str)

            with get_db_connection() as conn:
                with conn.cursor() as cur:
                    code = generate_appointment_code(cur)
                    cur.execute("""
                        INSERT INTO public.appointments 
                        (appointment_code, patient_id, doctor_id, appointment_date, reason, status, notes, created_by)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s);
                    """, (code, patient_id, doctor_id, appointment_date, reason, status, notes, created_by))
                    conn.commit()

            flash(f"Appointment {code} booked successfully!", "success")
            return redirect(url_for("appointments.index"))

        return render_template("appointments/form.html", patients=patients, doctors=doctors, appointment={}, action="Book")

    except Exception as e:
        flash(f"Error booking appointment: {str(e)}", "danger")
        return redirect(url_for("appointments.index"))

@appointments_bp.route("/edit/<int:appointment_id>", methods=["GET", "POST"])
@login_required
def edit(appointment_id):
    try:
        with get_db_connection() as conn:
            with conn.cursor(row_factory=dict_row) as cur:
                cur.execute("SELECT * FROM public.appointments WHERE appointment_id = %s;", (appointment_id,))
                appointment = cur.fetchone()

                cur.execute("SELECT patient_id, patient_code, first_name, last_name, phone FROM public.patients WHERE is_active = TRUE ORDER BY first_name ASC;")
                patients = cur.fetchall()

                cur.execute("SELECT doctor_id, doctor_name, specialization FROM public.doctors WHERE is_active = TRUE ORDER BY doctor_name ASC;")
                doctors = cur.fetchall()

        if not appointment:
            flash("Appointment not found!", "warning")
            return redirect(url_for("appointments.index"))

        if request.method == "POST":
            patient_id = request.form.get("patient_id")
            doctor_id = request.form.get("doctor_id")
            appointment_date_str = request.form.get("appointment_date")
            reason = request.form.get("reason", "").strip()
            notes = request.form.get("notes", "").strip()
            status = request.form.get("status", "Scheduled")

            appointment_date = datetime.fromisoformat(appointment_date_str)

            with get_db_connection() as conn:
                with conn.cursor() as cur:
                    cur.execute("""
                        UPDATE public.appointments 
                        SET patient_id = %s, doctor_id = %s, appointment_date = %s,
                            reason = %s, status = %s, notes = %s
                        WHERE appointment_id = %s;
                    """, (patient_id, doctor_id, appointment_date, reason, status, notes, appointment_id))
                    conn.commit()

            flash("Appointment updated successfully!", "success")
            return redirect(url_for("appointments.index"))

        if appointment.get("appointment_date"):
            appointment["formatted_date"] = appointment["appointment_date"].strftime("%Y-%m-%dT%H:%M")

        return render_template("appointments/form.html", patients=patients, doctors=doctors, appointment=appointment, action="Edit")

    except Exception as e:
        flash(f"Error updating appointment: {str(e)}", "danger")
        return redirect(url_for("appointments.index"))

@appointments_bp.route("/update-status/<int:appointment_id>/<new_status>", methods=["POST"])
@login_required
def update_status(appointment_id, new_status):
    if new_status not in ["Scheduled", "Completed", "Cancelled"]:
        flash("Invalid status specified!", "danger")
        return redirect(url_for("appointments.index"))

    try:
        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("UPDATE public.appointments SET status = %s WHERE appointment_id = %s;", (new_status, appointment_id))
                conn.commit()
        flash(f"Appointment status changed to {new_status}!", "success")
    except Exception as e:
        flash(f"Error updating status: {str(e)}", "danger")

    return redirect(url_for("appointments.index"))