from flask import Blueprint, render_template, redirect, url_for
from flask_login import login_required, current_user
from app import get_db_connection
from psycopg.rows import dict_row

dashboard_bp = Blueprint("dashboard", __name__)

# Root URL (/) handler: bina login ke /login par bhejega, login hone par dashboard dikhayega
@dashboard_bp.route("/")
def root():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard.index"))
    return redirect(url_for("auth.login"))

@dashboard_bp.route("/dashboard")
@login_required
def index():
    stats = {
        "active_patients": 0,
        "active_doctors": 0,
        "today_appointments": 0,
        "total_revenue": 0.0,
        "current_admissions": 0,
        "low_stock_medicines": 0
    }
    recent_appointments = []
    recent_admissions = []
    error = None

    try:
        with get_db_connection() as conn:
            with conn.cursor(row_factory=dict_row) as cur:
                cur.execute("SELECT COUNT(*) FROM public.patients WHERE is_active = TRUE;")
                stats["active_patients"] = cur.fetchone()["count"]

                cur.execute("SELECT COUNT(*) FROM public.doctors WHERE is_active = TRUE;")
                stats["active_doctors"] = cur.fetchone()["count"]

                cur.execute("SELECT COUNT(*) FROM public.appointments WHERE DATE(appointment_date) = CURRENT_DATE;")
                stats["today_appointments"] = cur.fetchone()["count"]

                cur.execute("SELECT COALESCE(SUM(amount), 0) AS total FROM public.payments WHERE payment_status = 'Completed';")
                stats["total_revenue"] = float(cur.fetchone()["total"] or 0)

                cur.execute("SELECT COUNT(*) FROM public.admissions WHERE status = 'Admitted';")
                stats["current_admissions"] = cur.fetchone()["count"]

                cur.execute("SELECT COUNT(*) FROM public.medicines WHERE quantity_in_stock <= reorder_level AND is_active = TRUE;")
                stats["low_stock_medicines"] = cur.fetchone()["count"]

                cur.execute("""
                    SELECT 
                        a.appointment_code,
                        CONCAT(p.first_name, ' ', p.last_name) AS patient_name,
                        d.doctor_name,
                        a.appointment_date,
                        a.status
                    FROM public.appointments a
                    JOIN public.patients p ON a.patient_id = p.patient_id
                    JOIN public.doctors d ON a.doctor_id = d.doctor_id
                    ORDER BY a.appointment_date DESC
                    LIMIT 5;
                """)
                recent_appointments = cur.fetchall()

                cur.execute("""
                    SELECT 
                        a.admission_code,
                        CONCAT(p.first_name, ' ', p.last_name) AS patient_name,
                        a.room_number,
                        a.bed_number,
                        a.status,
                        a.admission_date
                    FROM public.admissions a
                    JOIN public.patients p ON a.patient_id = p.patient_id
                    ORDER BY a.admission_date DESC
                    LIMIT 5;
                """)
                recent_admissions = cur.fetchall()

    except Exception as e:
        error = f"Database Error: {str(e)}"

    return render_template(
        "dashboard.html",
        stats=stats,
        recent_appointments=recent_appointments,
        recent_admissions=recent_admissions,
        error=error
    )

# Alias to prevent BuildError for 'dashboard.home'
@dashboard_bp.route("/home")
@login_required
def home():
    return index()