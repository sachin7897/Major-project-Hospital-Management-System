from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required
from app import get_db_connection
from psycopg.rows import dict_row
from datetime import datetime

admissions_bp = Blueprint("admissions", __name__, url_prefix="/admissions")

def generate_admission_code(cursor):
    cursor.execute("SELECT COALESCE(MAX(admission_id), 0) + 1 FROM public.admissions;")
    next_id = cursor.fetchone()[0]
    return f"ADM-{next_id:04d}"

@admissions_bp.route("/", methods=["GET"])
@login_required
def index():
    status_filter = request.args.get("status", "").strip()
    search = request.args.get("q", "").strip()
    admissions = []
    error = None

    try:
        with get_db_connection() as conn:
            with conn.cursor(row_factory=dict_row) as cur:
                base_query = """
                    SELECT 
                        a.admission_id,
                        a.admission_code,
                        a.admission_date,
                        a.discharge_date,
                        a.room_number,
                        a.bed_number,
                        a.admission_reason,
                        a.status,
                        p.patient_id,
                        p.patient_code,
                        CONCAT(p.first_name, ' ', p.last_name) AS patient_name,
                        p.phone AS patient_phone,
                        d.doctor_id,
                        d.doctor_name,
                        d.specialization
                    FROM public.admissions a
                    JOIN public.patients p ON a.patient_id = p.patient_id
                    JOIN public.doctors d ON a.doctor_id = d.doctor_id
                    WHERE 1=1
                """
                params = []

                if status_filter:
                    base_query += " AND a.status = %s"
                    params.append(status_filter)

                if search:
                    base_query += """ AND (
                        a.admission_code ILIKE %s OR
                        CONCAT(p.first_name, ' ', p.last_name) ILIKE %s OR
                        d.doctor_name ILIKE %s OR
                        a.room_number ILIKE %s OR
                        a.bed_number ILIKE %s OR
                        a.admission_reason ILIKE %s
                    )"""
                    p = f"%{search}%"
                    params.extend([p, p, p, p, p, p])

                base_query += " ORDER BY a.admission_date DESC;"

                cur.execute(base_query, tuple(params))
                admissions = cur.fetchall()

    except Exception as e:
        error = f"Database Error: {str(e)}"

    stats = {
        "total": len(admissions),
        "admitted": sum(1 for a in admissions if a.get("status") == "Admitted"),
        "discharged": sum(1 for a in admissions if a.get("status") == "Discharged")
    }

    return render_template(
        "admissions/index.html",
        admissions=admissions,
        status_filter=status_filter,
        search=search,
        stats=stats,
        error=error
    )

@admissions_bp.route("/admit", methods=["GET", "POST"])
@login_required
def admit():
    try:
        with get_db_connection() as conn:
            with conn.cursor(row_factory=dict_row) as cur:
                cur.execute("SELECT patient_id, patient_code, first_name, last_name, phone FROM public.patients WHERE is_active = TRUE ORDER BY first_name ASC;")
                patients = cur.fetchall()

                cur.execute("SELECT doctor_id, doctor_name, specialization FROM public.doctors WHERE is_active = TRUE ORDER BY doctor_name ASC;")
                doctors = cur.fetchall()

        if request.method == "POST":
            patient_id = request.form.get("patient_id")
            doctor_id = request.form.get("doctor_id")
            admission_date_str = request.form.get("admission_date")
            room_number = request.form.get("room_number", "").strip()
            bed_number = request.form.get("bed_number", "").strip()
            admission_reason = request.form.get("admission_reason", "").strip()
            status = request.form.get("status", "Admitted")

            if not patient_id or not doctor_id or not admission_date_str:
                flash("Patient, Doctor and Admission Date are required!", "danger")
                return render_template("admissions/form.html", patients=patients, doctors=doctors, admission={}, action="Admit")

            admission_date = datetime.fromisoformat(admission_date_str)

            with get_db_connection() as conn:
                with conn.cursor() as cur:
                    code = generate_admission_code(cur)
                    cur.execute("""
                        INSERT INTO public.admissions 
                        (admission_code, patient_id, doctor_id, admission_date, room_number, bed_number, admission_reason, status)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s);
                    """, (code, patient_id, doctor_id, admission_date, room_number, bed_number, admission_reason, status))
                    conn.commit()

            flash(f"Patient admitted successfully! Code: {code}", "success")
            return redirect(url_for("admissions.index"))

        return render_template("admissions/form.html", patients=patients, doctors=doctors, admission={}, action="Admit")

    except Exception as e:
        flash(f"Error admitting patient: {str(e)}", "danger")
        return redirect(url_for("admissions.index"))

@admissions_bp.route("/edit/<int:admission_id>", methods=["GET", "POST"])
@login_required
def edit(admission_id):
    try:
        with get_db_connection() as conn:
            with conn.cursor(row_factory=dict_row) as cur:
                cur.execute("SELECT * FROM public.admissions WHERE admission_id = %s;", (admission_id,))
                admission = cur.fetchone()

                cur.execute("SELECT patient_id, patient_code, first_name, last_name, phone FROM public.patients WHERE is_active = TRUE ORDER BY first_name ASC;")
                patients = cur.fetchall()

                cur.execute("SELECT doctor_id, doctor_name, specialization FROM public.doctors WHERE is_active = TRUE ORDER BY doctor_name ASC;")
                doctors = cur.fetchall()

        if not admission:
            flash("Admission record not found!", "warning")
            return redirect(url_for("admissions.index"))

        if request.method == "POST":
            patient_id = request.form.get("patient_id")
            doctor_id = request.form.get("doctor_id")
            admission_date_str = request.form.get("admission_date")
            discharge_date_str = request.form.get("discharge_date") or None
            room_number = request.form.get("room_number", "").strip()
            bed_number = request.form.get("bed_number", "").strip()
            admission_reason = request.form.get("admission_reason", "").strip()
            status = request.form.get("status", "Admitted")

            admission_date = datetime.fromisoformat(admission_date_str) if admission_date_str else None
            discharge_date = datetime.fromisoformat(discharge_date_str) if discharge_date_str else None

            with get_db_connection() as conn:
                with conn.cursor() as cur:
                    cur.execute("""
                        UPDATE public.admissions 
                        SET patient_id = %s, doctor_id = %s, admission_date = %s,
                            discharge_date = %s, room_number = %s, bed_number = %s,
                            admission_reason = %s, status = %s
                        WHERE admission_id = %s;
                    """, (patient_id, doctor_id, admission_date, discharge_date, room_number, bed_number, admission_reason, status, admission_id))
                    conn.commit()

            flash("Admission details updated successfully!", "success")
            return redirect(url_for("admissions.index"))

        if admission.get("admission_date"):
            admission["formatted_admission_date"] = admission["admission_date"].strftime("%Y-%m-%dT%H:%M")
        if admission.get("discharge_date"):
            admission["formatted_discharge_date"] = admission["discharge_date"].strftime("%Y-%m-%dT%H:%M")

        return render_template("admissions/form.html", patients=patients, doctors=doctors, admission=admission, action="Edit")

    except Exception as e:
        flash(f"Error updating admission: {str(e)}", "danger")
        return redirect(url_for("admissions.index"))

@admissions_bp.route("/discharge/<int:admission_id>", methods=["POST"])
@login_required
def discharge(admission_id):
    try:
        now = datetime.now()
        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    UPDATE public.admissions 
                    SET status = 'Discharged', discharge_date = %s 
                    WHERE admission_id = %s;
                """, (now, admission_id))
                conn.commit()
        flash("Patient marked as Discharged successfully!", "success")
    except Exception as e:
        flash(f"Error discharging patient: {str(e)}", "danger")

    return redirect(url_for("admissions.index"))