from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required
from app import get_db_connection
from psycopg.rows import dict_row
from datetime import date

pharmacy_bp = Blueprint("pharmacy", __name__, url_prefix="/pharmacy")

def generate_medicine_code(cursor):
    cursor.execute("SELECT COALESCE(MAX(medicine_id), 0) + 1 FROM public.medicines;")
    next_id = cursor.fetchone()[0]
    return f"MED-{next_id:04d}"

@pharmacy_bp.route("/", methods=["GET"])
@login_required
def index():
    search = request.args.get("q", "").strip()
    filter_type = request.args.get("filter", "").strip()
    medicines = []
    error = None

    try:
        with get_db_connection() as conn:
            with conn.cursor(row_factory=dict_row) as cur:
                query = "SELECT * FROM public.medicines WHERE 1=1"
                params = []

                if search:
                    query += """ AND (
                        medicine_name ILIKE %s OR 
                        medicine_code ILIKE %s OR 
                        category ILIKE %s OR 
                        manufacturer ILIKE %s OR 
                        batch_number ILIKE %s
                    )"""
                    p = f"%{search}%"
                    params.extend([p, p, p, p, p])

                if filter_type == "low_stock":
                    query += " AND quantity_in_stock <= reorder_level"
                elif filter_type == "expired":
                    query += " AND expiry_date <= CURRENT_DATE"

                query += " ORDER BY medicine_id DESC;"
                cur.execute(query, tuple(params))
                medicines = cur.fetchall()

    except Exception as e:
        error = f"Database Error: {str(e)}"

    today = date.today()
    stats = {
        "total": len(medicines),
        "total_stock": sum(int(m.get("quantity_in_stock") or 0) for m in medicines),
        "low_stock": sum(1 for m in medicines if (m.get("quantity_in_stock") or 0) <= (m.get("reorder_level") or 0)),
        "expired": sum(1 for m in medicines if m.get("expiry_date") and m.get("expiry_date") <= today)
    }

    return render_template(
        "pharmacy/index.html",
        medicines=medicines,
        search=search,
        filter_type=filter_type,
        stats=stats,
        today=today,
        error=error
    )

@pharmacy_bp.route("/add", methods=["GET", "POST"])
@login_required
def add():
    if request.method == "POST":
        medicine_name = request.form.get("medicine_name", "").strip()
        category = request.form.get("category", "").strip()
        manufacturer = request.form.get("manufacturer", "").strip()
        batch_number = request.form.get("batch_number", "").strip()
        expiry_date = request.form.get("expiry_date") or None
        quantity_in_stock = int(request.form.get("quantity_in_stock") or 0)
        reorder_level = int(request.form.get("reorder_level") or 10)
        purchase_price = float(request.form.get("purchase_price") or 0.0)
        selling_price = float(request.form.get("selling_price") or 0.0)
        is_active = True if request.form.get("is_active") == "on" else False

        if not medicine_name:
            flash("Medicine Name is required!", "danger")
            return render_template("pharmacy/form.html", medicine={}, action="Add")

        try:
            with get_db_connection() as conn:
                with conn.cursor() as cur:
                    code = generate_medicine_code(cur)
                    cur.execute("""
                        INSERT INTO public.medicines 
                        (medicine_code, medicine_name, category, manufacturer, batch_number, 
                         expiry_date, quantity_in_stock, reorder_level, purchase_price, selling_price, is_active)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);
                    """, (code, medicine_name, category, manufacturer, batch_number, 
                          expiry_date, quantity_in_stock, reorder_level, purchase_price, selling_price, is_active))
                    conn.commit()
            flash(f"Medicine {medicine_name} ({code}) added successfully!", "success")
            return redirect(url_for("pharmacy.index"))
        except Exception as e:
            flash(f"Error adding medicine: {str(e)}", "danger")

    return render_template("pharmacy/form.html", medicine={}, action="Add")

@pharmacy_bp.route("/edit/<int:medicine_id>", methods=["GET", "POST"])
@login_required
def edit(medicine_id):
    try:
        with get_db_connection() as conn:
            with conn.cursor(row_factory=dict_row) as cur:
                cur.execute("SELECT * FROM public.medicines WHERE medicine_id = %s;", (medicine_id,))
                medicine = cur.fetchone()

        if not medicine:
            flash("Medicine not found!", "warning")
            return redirect(url_for("pharmacy.index"))

        if request.method == "POST":
            medicine_name = request.form.get("medicine_name", "").strip()
            category = request.form.get("category", "").strip()
            manufacturer = request.form.get("manufacturer", "").strip()
            batch_number = request.form.get("batch_number", "").strip()
            expiry_date = request.form.get("expiry_date") or None
            quantity_in_stock = int(request.form.get("quantity_in_stock") or 0)
            reorder_level = int(request.form.get("reorder_level") or 10)
            purchase_price = float(request.form.get("purchase_price") or 0.0)
            selling_price = float(request.form.get("selling_price") or 0.0)
            is_active = True if request.form.get("is_active") == "on" else False

            with get_db_connection() as conn:
                with conn.cursor() as cur:
                    cur.execute("""
                        UPDATE public.medicines 
                        SET medicine_name = %s, category = %s, manufacturer = %s, batch_number = %s,
                            expiry_date = %s, quantity_in_stock = %s, reorder_level = %s,
                            purchase_price = %s, selling_price = %s, is_active = %s
                        WHERE medicine_id = %s;
                    """, (medicine_name, category, manufacturer, batch_number,
                          expiry_date, quantity_in_stock, reorder_level,
                          purchase_price, selling_price, is_active, medicine_id))
                    conn.commit()

            flash("Medicine details updated successfully!", "success")
            return redirect(url_for("pharmacy.index"))

        return render_template("pharmacy/form.html", medicine=medicine, action="Edit")

    except Exception as e:
        flash(f"Error updating medicine: {str(e)}", "danger")
        return redirect(url_for("pharmacy.index"))

@pharmacy_bp.route("/dispense/<int:medicine_id>", methods=["POST"])
@login_required
def dispense(medicine_id):
    try:
        qty_to_dispense = int(request.form.get("qty", 1))
        with get_db_connection() as conn:
            with conn.cursor(row_factory=dict_row) as cur:
                cur.execute("SELECT medicine_name, quantity_in_stock FROM public.medicines WHERE medicine_id = %s;", (medicine_id,))
                med = cur.fetchone()

                if not med:
                    flash("Medicine not found!", "danger")
                    return redirect(url_for("pharmacy.index"))

                if med["quantity_in_stock"] < qty_to_dispense:
                    flash(f"Insufficient stock for {med['medicine_name']}! Available: {med['quantity_in_stock']}", "danger")
                    return redirect(url_for("pharmacy.index"))

                cur.execute("""
                    UPDATE public.medicines 
                    SET quantity_in_stock = quantity_in_stock - %s 
                    WHERE medicine_id = %s;
                """, (qty_to_dispense, medicine_id))
                conn.commit()

        flash(f"Dispensed {qty_to_dispense} units of {med['medicine_name']} successfully!", "success")
    except Exception as e:
        flash(f"Error dispensing stock: {str(e)}", "danger")

    return redirect(url_for("pharmacy.index"))

@pharmacy_bp.route("/toggle-status/<int:medicine_id>", methods=["POST"])
@login_required
def toggle_status(medicine_id):
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("UPDATE public.medicines SET is_active = NOT is_active WHERE medicine_id = %s;", (medicine_id,))
                conn.commit()
        flash("Medicine status updated!", "success")
    except Exception as e:
        flash(f"Error updating status: {str(e)}", "danger")
    return redirect(url_for("pharmacy.index"))