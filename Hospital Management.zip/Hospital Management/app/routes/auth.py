from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from app import get_db_connection
from psycopg.rows import dict_row

auth_bp = Blueprint("auth", __name__)

@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard.index"))

    if request.method == "POST":
        username_or_email = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()

        if not username_or_email or not password:
            flash("Enter Username / Email aur Password.", "warning")
            return render_template("login.html")

        try:
            with get_db_connection() as conn:
                with conn.cursor(row_factory=dict_row) as cur:
                    cur.execute("""
                        SELECT * FROM public.users 
                        WHERE (username = %s OR email = %s) AND is_active = TRUE;
                    """, (username_or_email, username_or_email))
                    user_data = cur.fetchone()

            if user_data and (check_password_hash(user_data["password_hash"], password) or user_data["password_hash"] == password):
                from app.models import User
                user_obj = User(
                    user_id=user_data["user_id"],
                    username=user_data["username"],
                    role=user_data.get("role", "admin"),
                    full_name=user_data.get("full_name", user_data["username"])
                )
                login_user(user_obj)
                flash(f"Welcome back, {user_obj.full_name}!", "success")
                return redirect(url_for("dashboard.index"))
            else:
                flash("Invalid login credentials / account inactive.", "danger")

        except Exception as e:
            flash(f"Login Error: {str(e)}", "danger")

    return render_template("login.html")


@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard.index"))

    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "").strip()
        role = request.form.get("role", "staff").strip()

        if not full_name or not username or not email or not password:
            flash("Please Fill All Field", "warning")
            return render_template("register.html")

        hashed_password = generate_password_hash(password)

        try:
            with get_db_connection() as conn:
                with conn.cursor(row_factory=dict_row) as cur:
                    cur.execute("SELECT user_id FROM public.users WHERE username = %s OR email = %s;", (username, email))
                    if cur.fetchone():
                        flash("Account Already Exist", "warning")
                        return render_template("register.html")

                    cur.execute("""
                        INSERT INTO public.users (full_name, username, email, password_hash, role, is_active)
                        VALUES (%s, %s, %s, %s, %s, TRUE);
                    """, (full_name, username, email, hashed_password, role))
                    conn.commit()

            flash("Create Account successfully .", "success")
            return redirect(url_for("auth.login"))

        except Exception as e:
            flash(f"Registration Error: {str(e)}", "danger")

    return render_template("register.html")


@auth_bp.route("/logout", methods=["GET", "POST"])
@login_required
def logout():
    logout_user()
    flash("logout Successfully", "info")
    return redirect(url_for("auth.login"))