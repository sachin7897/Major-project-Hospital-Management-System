from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from app import get_db_connection
from psycopg.rows import dict_row
from datetime import datetime, date

billing_bp = Blueprint("billing", __name__, url_prefix="/billing")

def generate_invoice_number(cursor):
    cursor.execute("SELECT COALESCE(MAX(invoice_id), 0) + 1 FROM public.invoices;")
    next_id = cursor.fetchone()[0]
    return f"INV-{next_id:05d}"

def generate_payment_reference(cursor):
    cursor.execute("SELECT COALESCE(MAX(payment_id), 0) + 1 FROM public.payments;")
    next_id = cursor.fetchone()[0]
    return f"PAY-{next_id:05d}"

@billing_bp.route("/", methods=["GET"])
@login_required
def index():
    status_filter = request.args.get("status", "").strip()
    search = request.args.get("q", "").strip()
    invoices = []
    error = None

    try:
        with get_db_connection() as conn:
            with conn.cursor(row_factory=dict_row) as cur:
                query = """
                    SELECT 
                        i.invoice_id,
                        i.invoice_number,
                        i.invoice_date,
                        i.due_date,
                        i.subtotal,
                        i.discount_amount,
                        i.tax_amount,
                        i.total_amount,
                        i.status,
                        p.patient_id,
                        p.patient_code,
                        CONCAT(p.first_name, ' ', p.last_name) AS patient_name,
                        p.phone AS patient_phone,
                        COALESCE(SUM(pay.amount), 0) AS total_paid
                    FROM public.invoices i
                    JOIN public.patients p ON i.patient_id = p.patient_id
                    LEFT JOIN public.payments pay ON i.invoice_id = pay.invoice_id AND pay.payment_status = 'Completed'
                    WHERE 1=1
                """
                params = []

                if status_filter:
                    query += " AND i.status = %s"
                    params.append(status_filter)

                if search:
                    query += """ AND (
                        i.invoice_number ILIKE %s OR
                        CONCAT(p.first_name, ' ', p.last_name) ILIKE %s OR
                        p.patient_code ILIKE %s
                    )"""
                    pattern = f"%{search}%"
                    params.extend([pattern, pattern, pattern])

                query += " GROUP BY i.invoice_id, p.patient_id ORDER BY i.invoice_date DESC;"

                cur.execute(query, tuple(params))
                invoices = cur.fetchall()

    except Exception as e:
        error = f"Database Error: {str(e)}"

    total_billed = sum(float(inv.get("total_amount") or 0) for inv in invoices)
    total_received = sum(float(inv.get("total_paid") or 0) for inv in invoices)

    stats = {
        "count": len(invoices),
        "total_billed": total_billed,
        "total_received": total_received,
        "pending_amount": max(0.0, total_billed - total_received)
    }

    return render_template(
        "billing/index.html",
        invoices=invoices,
        status_filter=status_filter,
        search=search,
        stats=stats,
        error=error
    )

@billing_bp.route("/create", methods=["GET", "POST"])
@login_required
def create():
    try:
        with get_db_connection() as conn:
            with conn.cursor(row_factory=dict_row) as cur:
                cur.execute("SELECT patient_id, patient_code, first_name, last_name, phone FROM public.patients WHERE is_active = TRUE ORDER BY first_name ASC;")
                patients = cur.fetchall()

        if request.method == "POST":
            patient_id = request.form.get("patient_id")
            invoice_date_str = request.form.get("invoice_date") or str(date.today())
            due_date_str = request.form.get("due_date") or None
            subtotal = float(request.form.get("subtotal") or 0.0)
            discount = float(request.form.get("discount_amount") or 0.0)
            tax = float(request.form.get("tax_amount") or 0.0)
            total = max(0.0, (subtotal - discount) + tax)
            status = request.form.get("status", "Unpaid")
            notes = request.form.get("notes", "").strip()

            if not patient_id:
                flash("Please select a patient!", "danger")
                return render_template("billing/form.html", patients=patients, today=str(date.today()))

            with get_db_connection() as conn:
                with conn.cursor() as cur:
                    inv_no = generate_invoice_number(cur)
                    cur.execute("""
                        INSERT INTO public.invoices 
                        (invoice_number, patient_id, invoice_date, due_date, subtotal, discount_amount, tax_amount, total_amount, status, notes)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                        RETURNING invoice_id;
                    """, (inv_no, patient_id, invoice_date_str, due_date_str, subtotal, discount, tax, total, status, notes))
                    invoice_id = cur.fetchone()[0]

                    if status == "Paid" and total > 0:
                        pay_ref = generate_payment_reference(cur)
                        user_id = getattr(current_user, "user_id", None)
                        cur.execute("""
                            INSERT INTO public.payments 
                            (payment_reference, invoice_id, amount, payment_method, payment_status, transaction_date, notes, created_by)
                            VALUES (%s, %s, %s, %s, %s, %s, %s, %s);
                        """, (pay_ref, invoice_id, total, "Cash", "Completed", datetime.now(), "Initial full settlement", user_id))

                    conn.commit()

            flash(f"Invoice {inv_no} generated successfully!", "success")
            return redirect(url_for("billing.index"))

        return render_template("billing/form.html", patients=patients, today=str(date.today()))

    except Exception as e:
        flash(f"Error creating invoice: {str(e)}", "danger")
        return redirect(url_for("billing.index"))

@billing_bp.route("/view/<int:invoice_id>")
@login_required
def view_invoice(invoice_id):
    try:
        with get_db_connection() as conn:
            with conn.cursor(row_factory=dict_row) as cur:
                cur.execute("""
                    SELECT 
                        i.*,
                        p.patient_code,
                        p.first_name,
                        p.last_name,
                        p.phone,
                        p.email,
                        p.address
                    FROM public.invoices i
                    JOIN public.patients p ON i.patient_id = p.patient_id
                    WHERE i.invoice_id = %s;
                """, (invoice_id,))
                invoice = cur.fetchone()

                if not invoice:
                    flash("Invoice not found!", "warning")
                    return redirect(url_for("billing.index"))

                cur.execute("""
                    SELECT * FROM public.payments 
                    WHERE invoice_id = %s 
                    ORDER BY transaction_date DESC;
                """, (invoice_id,))
                payments = cur.fetchall()

        total_paid = sum(float(p.get("amount") or 0) for p in payments if p.get("payment_status") == "Completed")
        balance_due = max(0.0, float(invoice.get("total_amount") or 0) - total_paid)

        return render_template(
            "billing/invoice.html",
            invoice=invoice,
            payments=payments,
            total_paid=total_paid,
            balance_due=balance_due
        )

    except Exception as e:
        flash(f"Error loading invoice: {str(e)}", "danger")
        return redirect(url_for("billing.index"))

@billing_bp.route("/payment/<int:invoice_id>", methods=["POST"])
@login_required
def record_payment(invoice_id):
    try:
        amount = float(request.form.get("amount") or 0.0)
        method = request.form.get("payment_method", "Cash")
        notes = request.form.get("notes", "").strip()
        user_id = getattr(current_user, "user_id", None)

        if amount <= 0:
            flash("Payment amount must be greater than zero!", "danger")
            return redirect(url_for("billing.view_invoice", invoice_id=invoice_id))

        with get_db_connection() as conn:
            with conn.cursor(row_factory=dict_row) as cur:
                pay_ref = generate_payment_reference(cur)
                cur.execute("""
                    INSERT INTO public.payments 
                    (payment_reference, invoice_id, amount, payment_method, payment_status, transaction_date, notes, created_by)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s);
                """, (pay_ref, invoice_id, amount, method, "Completed", datetime.now(), notes, user_id))

                cur.execute("SELECT total_amount FROM public.invoices WHERE invoice_id = %s;", (invoice_id,))
                total_amount = float(cur.fetchone()["total_amount"] or 0)

                cur.execute("SELECT COALESCE(SUM(amount), 0) FROM public.payments WHERE invoice_id = %s AND payment_status = 'Completed';", (invoice_id,))
                paid_so_far = float(cur.fetchone()[0] or 0)

                new_status = "Paid" if paid_so_far >= total_amount else "Partially Paid"
                cur.execute("UPDATE public.invoices SET status = %s WHERE invoice_id = %s;", (new_status, invoice_id))
                conn.commit()

        flash(f"Payment of ₹{amount:,.2f} recorded successfully ({pay_ref})!", "success")
        return redirect(url_for("billing.view_invoice", invoice_id=invoice_id))

    except Exception as e:
        flash(f"Error processing payment: {str(e)}", "danger")
        return redirect(url_for("billing.view_invoice", invoice_id=invoice_id))