from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required
from app import get_db_connection
from psycopg.rows import dict_row

doctors_bp = Blueprint("doctors", __name__, url_prefix="/doctors")

def get_doctor_columns():
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT column_name 
                    FROM information_schema.columns 
                    WHERE table_name = 'doctors' AND table_schema = 'public';
                """)
                return [row[0] for row in cur.fetchall()]
    except Exception:
        return []

@doctors_bp.route("/", methods=["GET"])
@login_required
def index():
    search = request.args.get("q", "").strip()
    doctors = []
    error = None

    try:
        with get_db_connection() as conn:
            with conn.cursor(row_factory=dict_row) as cur:
                if search:
                    query = """
                        SELECT * FROM public.doctors 
                        WHERE doctor_name ILIKE %s 
                           OR specialization ILIKE %s 
                           OR phone ILIKE %s 
                           OR email ILIKE %s
                        ORDER BY doctor_id DESC;
                    """
                    pattern = f"%{search}%"
                    cur.execute(query, (pattern, pattern, pattern, pattern))
                else:
                    cur.execute("SELECT * FROM public.doctors ORDER BY doctor_id DESC;")
                doctors = cur.fetchall()

    except Exception as e:
        error = f"Database Error: {str(e)}"

    stats = {
        "total": len(doctors),
        "active": sum(1 for d in doctors if d.get("is_active") is True),
        "inactive": sum(1 for d in doctors if d.get("is_active") is False)
    }

    return render_template(
        "doctors/index.html",
        doctors=doctors,
        search=search,
        error=error,
        stats=stats
    )

@doctors_bp.route("/add", methods=["GET", "POST"])
@login_required
def add():
    if request.method == "POST":
        doctor_name = request.form.get("doctor_name", "").strip()
        specialization = request.form.get("specialization", "").strip()
        qualification = request.form.get("qualification", "").strip()
        phone = request.form.get("phone", "").strip()
        email = request.form.get("email", "").strip()
        fee = request.form.get("consultation_fee") or 0.0
        available_from = request.form.get("available_from") or None
        available_to = request.form.get("available_to") or None
        is_active = True if request.form.get("is_active") == "on" else False

        if not doctor_name:
            flash("Doctor Name is required!", "danger")
            return render_template("doctors/form.html", doctor={}, action="Add")

        try:
            with get_db_connection() as conn:
                with conn.cursor() as cur:
                    cur.execute("""
                        INSERT INTO public.doctors 
                        (doctor_name, specialization, qualification, phone, email, consultation_fee, available_from, available_to, is_active)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s);
                    """, (doctor_name, specialization, qualification, phone, email, fee, available_from, available_to, is_active))
                    conn.commit()
            flash("Doctor added successfully!", "success")
            return redirect(url_for("doctors.index"))
        except Exception as e:
            flash(f"Error adding doctor: {str(e)}", "danger")

    return render_template("doctors/form.html", doctor={}, action="Add")

@doctors_bp.route("/edit/<int:doctor_id>", methods=["GET", "POST"])
@login_required
def edit(doctor_id):
    try:
        with get_db_connection() as conn:
            with conn.cursor(row_factory=dict_row) as cur:
                cur.execute("SELECT * FROM public.doctors WHERE doctor_id = %s;", (doctor_id,))
                doctor = cur.fetchone()

        if not doctor:
            flash("Doctor not found!", "warning")
            return redirect(url_for("doctors.index"))

        if request.method == "POST":
            doctor_name = request.form.get("doctor_name", "").strip()
            specialization = request.form.get("specialization", "").strip()
            qualification = request.form.get("qualification", "").strip()
            phone = request.form.get("phone", "").strip()
            email = request.form.get("email", "").strip()
            fee = request.form.get("consultation_fee") or 0.0
            available_from = request.form.get("available_from") or None
            available_to = request.form.get("available_to") or None
            is_active = True if request.form.get("is_active") == "on" else False

            with get_db_connection() as conn:
                with conn.cursor() as cur:
                    cur.execute("""
                        UPDATE public.doctors 
                        SET doctor_name = %s, specialization = %s, qualification = %s,
                            phone = %s, email = %s, consultation_fee = %s,
                            available_from = %s, available_to = %s, is_active = %s
                        WHERE doctor_id = %s;
                    """, (doctor_name, specialization, qualification, phone, email, fee, available_from, available_to, is_active, doctor_id))
                    conn.commit()
            flash("Doctor updated successfully!", "success")
            return redirect(url_for("doctors.index"))

        return render_template("doctors/form.html", doctor=doctor, action="Edit")

    except Exception as e:
        flash(f"Error: {str(e)}", "danger")
        return redirect(url_for("doctors.index"))

@doctors_bp.route("/toggle-status/<int:doctor_id>", methods=["POST"])
@login_required
def toggle_status(doctor_id):
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    UPDATE public.doctors 
                    SET is_active = NOT is_active 
                    WHERE doctor_id = %s;
                """, (doctor_id,))
                conn.commit()
        flash("Doctor status updated!", "success")
    except Exception as e:
        flash(f"Error updating status: {str(e)}", "danger")
    return redirect(url_for("doctors.index"))