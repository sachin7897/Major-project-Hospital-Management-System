from flask import Blueprint, render_template, Response, flash, redirect, url_for
from flask_login import login_required, current_user
from app import get_db_connection
from psycopg.rows import dict_row
import csv
import io
from datetime import datetime

reports_bp = Blueprint("reports", __name__, url_prefix="/reports")

@reports_bp.before_request
def check_admin_access():
    if not current_user.is_authenticated:
        return redirect(url_for("auth.login"))
    if getattr(current_user, "role", "").lower() != "admin":
        flash("Access Denied: Keval Hospital Administrator hi Reports & Audits dekh sakte hain.", "danger")
        return redirect(url_for("dashboard.index"))

@reports_bp.route("/", methods=["GET"])
@login_required
def index():
    metrics = {
        "patients_count": 0,
        "doctors_count": 0,
        "appointments_total": 0,
        "appointments_completed": 0,
        "total_revenue": 0.0,
        "total_collected": 0.0,
        "pending_bills": 0.0,
        "medicines_count": 0,
        "low_stock_medicines": 0,
        "admissions_current": 0,
        "admissions_total": 0
    }
    error = None

    try:
        with get_db_connection() as conn:
            with conn.cursor(row_factory=dict_row) as cur:
                # Patients
                cur.execute("SELECT COUNT(*) AS total FROM public.patients WHERE is_active = TRUE;")
                row = cur.fetchone()
                metrics["patients_count"] = row["total"] if row else 0

                # Doctors
                cur.execute("SELECT COUNT(*) AS total FROM public.doctors WHERE is_active = TRUE;")
                row = cur.fetchone()
                metrics["doctors_count"] = row["total"] if row else 0

                # Appointments
                cur.execute("SELECT COUNT(*) AS total FROM public.appointments;")
                row = cur.fetchone()
                metrics["appointments_total"] = row["total"] if row else 0

                cur.execute("SELECT COUNT(*) AS comp FROM public.appointments WHERE status = 'Completed';")
                row = cur.fetchone()
                metrics["appointments_completed"] = row["comp"] if row else 0

                # Invoices & Billing
                cur.execute("SELECT COALESCE(SUM(total_amount), 0) AS total FROM public.invoices;")
                row = cur.fetchone()
                metrics["total_revenue"] = float(row["total"] or 0)

                cur.execute("SELECT COALESCE(SUM(amount), 0) AS paid FROM public.payments WHERE payment_status = 'Completed';")
                row = cur.fetchone()
                metrics["total_collected"] = float(row["paid"] or 0)
                metrics["pending_bills"] = max(0.0, metrics["total_revenue"] - metrics["total_collected"])

                # Medicines & Stock
                cur.execute("SELECT COUNT(*) AS total FROM public.medicines WHERE is_active = TRUE;")
                row = cur.fetchone()
                metrics["medicines_count"] = row["total"] if row else 0

                cur.execute("SELECT COUNT(*) AS low FROM public.medicines WHERE quantity_in_stock <= reorder_level AND is_active = TRUE;")
                row = cur.fetchone()
                metrics["low_stock_medicines"] = row["low"] if row else 0

                # Admissions
                cur.execute("SELECT COUNT(*) AS total FROM public.admissions;")
                row = cur.fetchone()
                metrics["admissions_total"] = row["total"] if row else 0

                cur.execute("SELECT COUNT(*) AS cur_adm FROM public.admissions WHERE status = 'Admitted';")
                row = cur.fetchone()
                metrics["admissions_current"] = row["cur_adm"] if row else 0

    except Exception as e:
        error = f"Database Query Error: {str(e)}"

    return render_template("reports/index.html", metrics=metrics, error=error)

@reports_bp.route("/export/patients")
@login_required
def export_patients():
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Patient ID", "Patient Code", "First Name", "Last Name", "Phone", "Email", "Gender", "Blood Group", "Registration Date", "Status"])

    try:
        with get_db_connection() as conn:
            with conn.cursor(row_factory=dict_row) as cur:
                cur.execute("SELECT * FROM public.patients ORDER BY patient_id ASC;")
                for p in cur.fetchall():
                    writer.writerow([
                        p.get("patient_id"),
                        p.get("patient_code"),
                        p.get("first_name"),
                        p.get("last_name"),
                        p.get("phone"),
                        p.get("email"),
                        p.get("gender"),
                        p.get("blood_group"),
                        p.get("registration_date"),
                        "Active" if p.get("is_active") else "Inactive"
                    ])
    except Exception:
        pass

    output.seek(0)
    filename = f"MediCore_Patients_{datetime.now().strftime('%Y%m%d_%H%M')}.csv"
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment;filename={filename}"}
    )

@reports_bp.route("/export/appointments")
@login_required
def export_appointments():
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Appointment Code", "Patient Name", "Doctor Name", "Specialization", "Date & Time", "Status", "Reason"])

    try:
        with get_db_connection() as conn:
            with conn.cursor(row_factory=dict_row) as cur:
                cur.execute("""
                    SELECT 
                        a.appointment_code,
                        CONCAT(p.first_name, ' ', p.last_name) AS patient_name,
                        d.doctor_name,
                        d.specialization,
                        a.appointment_date,
                        a.status,
                        a.reason
                    FROM public.appointments a
                    LEFT JOIN public.patients p ON a.patient_id = p.patient_id
                    LEFT JOIN public.doctors d ON a.doctor_id = d.doctor_id
                    ORDER BY a.appointment_date DESC;
                """)
                for a in cur.fetchall():
                    writer.writerow([
                        a.get("appointment_code"),
                        a.get("patient_name"),
                        a.get("doctor_name"),
                        a.get("specialization"),
                        a.get("appointment_date"),
                        a.get("status"),
                        a.get("reason")
                    ])
    except Exception:
        pass

    output.seek(0)
    filename = f"MediCore_Appointments_{datetime.now().strftime('%Y%m%d_%H%M')}.csv"
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment;filename={filename}"}
    )

@reports_bp.route("/export/billing")
@login_required
def export_billing():
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Invoice Number", "Patient Name", "Phone", "Invoice Date", "Subtotal (INR)", "Discount (INR)", "Tax (INR)", "Total Amount (INR)", "Status"])

    try:
        with get_db_connection() as conn:
            with conn.cursor(row_factory=dict_row) as cur:
                cur.execute("""
                    SELECT 
                        i.invoice_number,
                        CONCAT(p.first_name, ' ', p.last_name) AS patient_name,
                        p.phone,
                        i.invoice_date,
                        i.subtotal,
                        i.discount_amount,
                        i.tax_amount,
                        i.total_amount,
                        i.status
                    FROM public.invoices i
                    LEFT JOIN public.patients p ON i.patient_id = p.patient_id
                    ORDER BY i.invoice_date DESC;
                """)
                for b in cur.fetchall():
                    writer.writerow([
                        b.get("invoice_number"),
                        b.get("patient_name"),
                        b.get("phone"),
                        b.get("invoice_date"),
                        b.get("subtotal"),
                        b.get("discount_amount"),
                        b.get("tax_amount"),
                        b.get("total_amount"),
                        b.get("status")
                    ])
    except Exception:
        pass

    output.seek(0)
    filename = f"MediCore_Billing_{datetime.now().strftime('%Y%m%d_%H%M')}.csv"
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment;filename={filename}"}
    )

@reports_bp.route("/export/pharmacy")
@login_required
def export_pharmacy():
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Code", "Medicine Name", "Category", "Manufacturer", "Batch No", "In Stock", "Reorder Level", "Purchase Price", "Selling Price", "Expiry Date", "Status"])

    try:
        with get_db_connection() as conn:
            with conn.cursor(row_factory=dict_row) as cur:
                cur.execute("SELECT * FROM public.medicines ORDER BY medicine_id ASC;")
                for m in cur.fetchall():
                    writer.writerow([
                        m.get("medicine_code"),
                        m.get("medicine_name"),
                        m.get("category"),
                        m.get("manufacturer"),
                        m.get("batch_number"),
                        m.get("quantity_in_stock"),
                        m.get("reorder_level"),
                        m.get("purchase_price"),
                        m.get("selling_price"),
                        m.get("expiry_date"),
                        "Active" if m.get("is_active") else "Inactive"
                    ])
    except Exception:
        pass

    output.seek(0)
    filename = f"MediCore_Pharmacy_{datetime.now().strftime('%Y%m%d_%H%M')}.csv"
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment;filename={filename}"}
    )

@reports_bp.route("/export/admissions")
@login_required
def export_admissions():
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Code", "Patient Name", "Doctor Name", "Room", "Bed", "Admission Date", "Discharge Date", "Status", "Reason"])

    try:
        with get_db_connection() as conn:
            with conn.cursor(row_factory=dict_row) as cur:
                cur.execute("""
                    SELECT 
                        a.admission_code,
                        CONCAT(p.first_name, ' ', p.last_name) AS patient_name,
                        d.doctor_name,
                        a.room_number,
                        a.bed_number,
                        a.admission_date,
                        a.discharge_date,
                        a.status,
                        a.admission_reason
                    FROM public.admissions a
                    LEFT JOIN public.patients p ON a.patient_id = p.patient_id
                    LEFT JOIN public.doctors d ON a.doctor_id = d.doctor_id
                    ORDER BY a.admission_date DESC;
                """)
                for adm in cur.fetchall():
                    writer.writerow([
                        adm.get("admission_code"),
                        adm.get("patient_name"),
                        adm.get("doctor_name"),
                        adm.get("room_number"),
                        adm.get("bed_number"),
                        adm.get("admission_date"),
                        adm.get("discharge_date"),
                        adm.get("status"),
                        adm.get("admission_reason")
                    ])
    except Exception:
        pass

    output.seek(0)
    filename = f"MediCore_Admissions_{datetime.now().strftime('%Y%m%d_%H%M')}.csv"
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment;filename={filename}"}
    )