import secrets

from datetime import date

from flask import (
    Blueprint,
    render_template,
    request,
    redirect,
    url_for,
    flash,
    current_app,
)

from flask_login import login_required
from psycopg.rows import dict_row

from app import get_db_connection


patients_bp = Blueprint(
    "patients",
    __name__,
    url_prefix="/patients"
)


@patients_bp.route("/")
@login_required
def index():
    search = request.args.get("search", "").strip()
    patients = []

    try:
        with get_db_connection() as connection:
            with connection.cursor(row_factory=dict_row) as cursor:

                if search:
                    cursor.execute(
                        """
                        SELECT
                            patient_id,
                            patient_code,
                            first_name,
                            last_name,
                            date_of_birth,
                            gender,
                            blood_group,
                            phone,
                            email,
                            registration_date,
                            is_active
                        FROM public.patients
                        WHERE
                            patient_code ILIKE %s
                            OR first_name ILIKE %s
                            OR COALESCE(last_name, '') ILIKE %s
                            OR COALESCE(phone, '') ILIKE %s
                        ORDER BY patient_id DESC
                        LIMIT 200
                        """,
                        (
                            f"%{search}%",
                            f"%{search}%",
                            f"%{search}%",
                            f"%{search}%",
                        ),
                    )
                else:
                    cursor.execute(
                        """
                        SELECT
                            patient_id,
                            patient_code,
                            first_name,
                            last_name,
                            date_of_birth,
                            gender,
                            blood_group,
                            phone,
                            email,
                            registration_date,
                            is_active
                        FROM public.patients
                        ORDER BY patient_id DESC
                        LIMIT 200
                        """
                    )

                patients = cursor.fetchall()

    except Exception:
        current_app.logger.exception(
            "Failed to load patients"
        )
        flash(
            "Unable to load patient records.",
            "error"
        )

    return render_template(
        "patients/index.html",
        patients=patients,
        search=search,
    )


@patients_bp.route("/new", methods=["GET", "POST"])
@login_required
def create():
    if request.method == "POST":

        first_name = request.form.get(
            "first_name", ""
        ).strip()

        last_name = request.form.get(
            "last_name", ""
        ).strip()

        date_of_birth = request.form.get(
            "date_of_birth", ""
        ).strip()

        gender = request.form.get(
            "gender", ""
        ).strip()

        blood_group = request.form.get(
            "blood_group", ""
        ).strip()

        phone = request.form.get(
            "phone", ""
        ).strip()

        email = request.form.get(
            "email", ""
        ).strip()

        address = request.form.get(
            "address", ""
        ).strip()

        emergency_contact_name = request.form.get(
            "emergency_contact_name", ""
        ).strip()

        emergency_contact_phone = request.form.get(
            "emergency_contact_phone", ""
        ).strip()

        allergies = request.form.get(
            "allergies", ""
        ).strip()

        if not first_name:
            flash("Patient first name is required.", "error")
            return render_template(
                "patients/form.html",
                patient=request.form,
                today=date.today().isoformat(),
            )

        if gender and gender not in (
            "Male", "Female", "Other"
        ):
            flash("Please select a valid gender.", "error")
            return render_template(
                "patients/form.html",
                patient=request.form,
                today=date.today().isoformat(),
            )

        if blood_group and blood_group not in (
            "A+", "A-", "B+", "B-", "AB+", "AB-",
            "O+", "O-"
        ):
            flash("Please select a valid blood group.", "error")
            return render_template(
                "patients/form.html",
                patient=request.form,
                today=date.today().isoformat(),
            )

        try:
            dob = (
                date.fromisoformat(date_of_birth)
                if date_of_birth
                else None
            )

            if dob and dob > date.today():
                flash(
                    "Date of birth cannot be in the future.",
                    "error"
                )
                return render_template(
                    "patients/form.html",
                    patient=request.form,
                    today=date.today().isoformat(),
                )

        except ValueError:
            flash("Invalid date of birth.", "error")
            return render_template(
                "patients/form.html",
                patient=request.form,
                today=date.today().isoformat(),
            )

        patient_code = (
            "PAT-" + secrets.token_hex(4).upper()
        )

        try:
            with get_db_connection() as connection:
                with connection.cursor() as cursor:
                    cursor.execute(
                        """
                        INSERT INTO public.patients (
                            patient_code,
                            first_name,
                            last_name,
                            date_of_birth,
                            gender,
                            blood_group,
                            phone,
                            email,
                            address,
                            emergency_contact_name,
                            emergency_contact_phone,
                            allergies
                        )
                        VALUES (
                            %s, %s, %s, %s, %s, %s,
                            %s, %s, %s, %s, %s, %s
                        )
                        RETURNING patient_id, patient_code
                        """,
                        (
                            patient_code,
                            first_name,
                            last_name or None,
                            dob,
                            gender or None,
                            blood_group or None,
                            phone or None,
                            email or None,
                            address or None,
                            emergency_contact_name or None,
                            emergency_contact_phone or None,
                            allergies or None,
                        ),
                    )

                    created_patient = cursor.fetchone()

            flash(
                f"Patient registered successfully. "
                f"Patient ID: {created_patient[1]}",
                "success",
            )

            return redirect(url_for("patients.index"))

        except Exception:
            current_app.logger.exception(
                "Patient registration failed"
            )
            flash(
                "Registration failed. Please check the "
                "form values and database constraints.",
                "error",
            )

            return render_template(
                "patients/form.html",
                patient=request.form,
                today=date.today().isoformat(),
            )

    return render_template(
        "patients/form.html",
        patient={},
        today=date.today().isoformat(),
    )