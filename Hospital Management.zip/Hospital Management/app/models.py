from flask_login import UserMixin

from app import login_manager


class User(UserMixin):
    def __init__(self, user_id, full_name, username, role):
        self.id = str(user_id)
        self.full_name = full_name
        self.username = username
        self.role = role


@login_manager.user_loader
def load_user(user_id):
    from app import get_db_connection

    try:
        with get_db_connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """
                    SELECT user_id, full_name, username, role, is_active
                    FROM public.users
                    WHERE user_id = %s
                    """,
                    (user_id,),
                )
                row = cursor.fetchone()

        if row and row[4]:
            return User(row[0], row[1], row[2], row[3])
    except Exception:
        return None

    return None
