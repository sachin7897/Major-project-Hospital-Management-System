import os

import psycopg
from dotenv import load_dotenv
from flask import Flask, jsonify
from flask_login import LoginManager
from flask_wtf.csrf import CSRFProtect

load_dotenv()

login_manager = LoginManager()
csrf = CSRFProtect()


def get_db_connection():
    """Create a PostgreSQL connection using values from the .env file."""
    return psycopg.connect(
        host=os.getenv("DB_HOST", "localhost"),
        port=os.getenv("DB_PORT", "5432"),
        dbname=os.getenv("DB_NAME", "hospital_management_db"),
        user=os.getenv("DB_USER", "postgres"),
        password=os.getenv("DB_PASSWORD", ""),
        connect_timeout=5,
    )


def create_app():
    app = Flask(__name__)

    # Set a long random SECRET_KEY in .env before using this outside local development.
    app.config["SECRET_KEY"] = os.getenv(
        "SECRET_KEY", "local-development-only-change-this-secret-key"
    )
    app.config["SESSION_COOKIE_HTTPONLY"] = True
    app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
    app.config["SESSION_COOKIE_SECURE"] = (
        os.getenv("COOKIE_SECURE", "false").lower() == "true"
    )

    login_manager.init_app(app)
    login_manager.login_view = "auth.login"
    login_manager.login_message = "Please sign in to access this page."
    login_manager.login_message_category = "warning"
    csrf.init_app(app)

    # Import models so Flask-Login registers the user loader.
    from app import models  # noqa: F401
    from app.routes.auth import auth_bp
    from app.routes.dashboard import dashboard_bp
    from app.routes.patients import patients_bp
    from app.routes.doctors import doctors_bp
    from app.routes.appointments import appointments_bp
    from app.routes.billing import billing_bp
    from app.routes.pharmacy import pharmacy_bp
    from app.routes.admissions import admissions_bp
    from app.routes.reports import reports_bp


    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(patients_bp)
    app.register_blueprint(doctors_bp)
    app.register_blueprint(appointments_bp)
    app.register_blueprint(billing_bp)
    app.register_blueprint(pharmacy_bp)
    app.register_blueprint(admissions_bp)
    app.register_blueprint(reports_bp)
    

    @app.get("/api/health")
    def health_check():
        try:
            with get_db_connection() as connection:
                with connection.cursor() as cursor:
                    cursor.execute(
                        "SELECT current_database(), current_user, version()"
                    )
                    database, user, version = cursor.fetchone()

            return jsonify({
                "status": "healthy",
                "database": database,
                "database_user": user,
                "postgresql_version": version.split(",")[0],
            })
        except psycopg.Error:
            app.logger.exception("Database health check failed")
            return jsonify({
                "status": "unhealthy",
                "message": "Database connection failed",
            }), 503

    return app
