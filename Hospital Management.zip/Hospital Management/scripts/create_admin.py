import os
import getpass

import psycopg
from dotenv import load_dotenv
from werkzeug.security import generate_password_hash


load_dotenv()


def main():
    print("\n=== MediCore Admin Setup ===\n")

    full_name = input("Enter admin full name: ").strip()
    username = input("Enter admin username: ").strip()
    email = input("Enter admin email: ").strip()

    if not full_name or not username or not email:
        print("Error: All fields are required.")
        return

    password = getpass.getpass("Create admin password: ")
    confirm_password = getpass.getpass("Confirm admin password: ")

    if password != confirm_password:
        print("Error: Passwords do not match.")
        return

    if len(password) < 12:
        print("Error: Use a password of at least 12 characters.")
        return

    password_hash = generate_password_hash(password)

    try:
        with psycopg.connect(
            host=os.getenv("DB_HOST", "localhost"),
            port=os.getenv("DB_PORT", "5432"),
            dbname=os.getenv("DB_NAME", "hospital_management_db"),
            user=os.getenv("DB_USER", "postgres"),
            password=os.getenv("DB_PASSWORD"),
            connect_timeout=5,
        ) as connection:

            with connection.cursor() as cursor:
                cursor.execute(
                    """
                    INSERT INTO public.users
                        (full_name, username, email, password_hash, role)
                    VALUES
                        (%s, %s, %s, %s, 'admin')
                    RETURNING user_id, full_name, username, role;
                    """,
                    (
                        full_name,
                        username,
                        email,
                        password_hash,
                    ),
                )

                user = cursor.fetchone()

        print("\nAdmin created successfully!")
        print(f"User ID: {user[0]}")
        print(f"Name: {user[1]}")
        print(f"Username: {user[2]}")
        print(f"Role: {user[3]}")

    except psycopg.errors.UniqueViolation:
        print(
            "Error: This username or email already exists. "
            "Choose a different one."
        )

    except psycopg.Error:
        print(
            "Database error. Check the Terminal for configuration "
            "issues and verify your database connection."
        )
        raise


if __name__ == "__main__":
    main()