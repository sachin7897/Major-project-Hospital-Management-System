-- ============================================================
-- MediCore Hospital Management System - Synthetic Demo Dataset
-- PostgreSQL 18
--
-- This file inserts fictional/demo records only. It contains no
-- real patient data. Run AFTER MediCore_Hospital_Database.sql.
--
-- Safe to re-run for these records: unique codes/names are used
-- with ON CONFLICT DO NOTHING.
--
-- NOTE: No login users/passwords are created here. The app should
-- create users with properly hashed passwords through its backend.
-- ============================================================

BEGIN;

-- 1. DEPARTMENTS
INSERT INTO public.departments (department_name, description)
VALUES
    ('General Medicine', 'General consultation and primary care'),
    ('Cardiology', 'Heart and cardiovascular care'),
    ('Orthopedics', 'Bone, joint and musculoskeletal care'),
    ('Pediatrics', 'Healthcare for children'),
    ('Dermatology', 'Skin and hair care'),
    ('Neurology', 'Brain and nervous system care'),
    ('Pathology', 'Laboratory and diagnostic services'),
    ('Pharmacy', 'Hospital medicine dispensing')
ON CONFLICT (department_name) DO NOTHING;

-- 2. DOCTORS
INSERT INTO public.doctors
    (department_id, doctor_name, specialization, qualification, phone, email,
     consultation_fee, available_from, available_to)
SELECT d.department_id, x.doctor_name, x.specialization, x.qualification,
       x.phone, x.email, x.consultation_fee, x.available_from, x.available_to
FROM (VALUES
    ('General Medicine', 'Dr. Aarav Sharma', 'General Physician', 'MBBS, MD', '9000000101', 'aarav.sharma.demo@example.test', 500.00, TIME '09:00', TIME '14:00'),
    ('Cardiology', 'Dr. Ananya Verma', 'Cardiologist', 'MBBS, DM Cardiology', '9000000102', 'ananya.verma.demo@example.test', 900.00, TIME '10:00', TIME '16:00'),
    ('Orthopedics', 'Dr. Vivaan Singh', 'Orthopedic Surgeon', 'MBBS, MS Orthopedics', '9000000103', 'vivaan.singh.demo@example.test', 800.00, TIME '09:00', TIME '13:00'),
    ('Pediatrics', 'Dr. Diya Gupta', 'Pediatrician', 'MBBS, MD Pediatrics', '9000000104', 'diya.gupta.demo@example.test', 600.00, TIME '11:00', TIME '17:00'),
    ('Dermatology', 'Dr. Arjun Mishra', 'Dermatologist', 'MBBS, MD Dermatology', '9000000105', 'arjun.mishra.demo@example.test', 700.00, TIME '12:00', TIME '18:00'),
    ('Neurology', 'Dr. Saanvi Patel', 'Neurologist', 'MBBS, DM Neurology', '9000000106', 'saanvi.patel.demo@example.test', 1000.00, TIME '10:00', TIME '15:00'),
    ('General Medicine', 'Dr. Reyansh Khan', 'General Physician', 'MBBS', '9000000107', 'reyansh.khan.demo@example.test', 400.00, TIME '15:00', TIME '19:00'),
    ('Pathology', 'Dr. Myra Joshi', 'Pathologist', 'MBBS, MD Pathology', '9000000108', 'myra.joshi.demo@example.test', 500.00, TIME '08:00', TIME '12:00')
) AS x(department_name, doctor_name, specialization, qualification, phone, email,
       consultation_fee, available_from, available_to)
JOIN public.departments d ON d.department_name = x.department_name
ON CONFLICT (email) DO NOTHING;

-- 3. PATIENTS: 30 fictional patients with clearly synthetic contact numbers.
INSERT INTO public.patients
    (patient_code, first_name, last_name, date_of_birth, gender, blood_group,
     phone, email, address, emergency_contact_name, emergency_contact_phone,
     allergies, registration_date)
SELECT
    'PAT-' || LPAD(gs::text, 4, '0'),
    (ARRAY['Aarav','Aditi','Rohan','Priya','Kabir','Isha','Vivaan','Anaya','Aditya','Meera',
           'Arnav','Sara','Ishaan','Kavya','Reyansh','Nisha','Krishna','Tara','Dev','Pihu',
           'Yash','Riya','Manav','Diya','Ayaan','Sana','Rahul','Simran','Kunal','Avni'])[((gs - 1) % 30) + 1],
    (ARRAY['Sharma','Verma','Singh','Gupta','Mishra','Patel','Khan','Joshi','Yadav','Mehta'])[((gs - 1) % 10) + 1],
    (DATE '1980-01-01' + ((gs * 431) % 15000)::integer),
    (ARRAY['Male','Female','Other'])[((gs - 1) % 3) + 1],
    (ARRAY['A+','B+','O+','AB+','A-','B-','O-','AB-'])[((gs - 1) % 8) + 1],
    '900000' || LPAD((2000 + gs)::text, 4, '0'),
    'patient' || gs || '@example.test',
    (ARRAY['Unnao','Kanpur','Lucknow','Hardoi','Kannauj'])[((gs - 1) % 5) + 1] || ', Uttar Pradesh',
    'Emergency Contact ' || gs,
    '900000' || LPAD((3000 + gs)::text, 4, '0'),
    CASE WHEN gs % 7 = 0 THEN 'Demo allergy note - verify clinically' ELSE NULL END,
    CURRENT_TIMESTAMP - ((gs % 45) || ' days')::interval
FROM generate_series(1, 30) AS gs
ON CONFLICT (patient_code) DO NOTHING;

-- 4. APPOINTMENTS: 30 appointments across past, present and future dates.
INSERT INTO public.appointments
    (appointment_code, patient_id, doctor_id, appointment_date, reason, status, notes)
SELECT
    'APT-DEMO-' || LPAD(gs::text, 4, '0'),
    p.patient_id,
    d.doctor_id,
    date_trunc('day', CURRENT_TIMESTAMP)
        + (((gs % 14) - 5) || ' days')::interval
        + ((9 + (gs % 8)) || ' hours')::interval,
    (ARRAY['General check-up','Follow-up visit','Headache consultation','Joint pain assessment',
           'Skin consultation','Child wellness visit','Heart health consultation','Routine review'])[((gs - 1) % 8) + 1],
    (ARRAY['Completed','Confirmed','Scheduled','Completed','Cancelled','No Show'])[((gs - 1) % 6) + 1],
    'Synthetic demonstration record'
FROM generate_series(1, 30) AS gs
JOIN public.patients p ON p.patient_code = 'PAT-' || LPAD(gs::text, 4, '0')
JOIN public.doctors d ON d.email = (
    ARRAY[
        'aarav.sharma.demo@example.test',
        'ananya.verma.demo@example.test',
        'vivaan.singh.demo@example.test',
        'diya.gupta.demo@example.test',
        'arjun.mishra.demo@example.test',
        'saanvi.patel.demo@example.test',
        'reyansh.khan.demo@example.test',
        'myra.joshi.demo@example.test'
    ])[((gs - 1) % 8) + 1]
ON CONFLICT (appointment_code) DO NOTHING;

-- 5. ADMISSIONS: 6 fictional admissions; some discharged, some active.
INSERT INTO public.admissions
    (admission_code, patient_id, doctor_id, admission_date, discharge_date,
     room_number, bed_number, admission_reason, status)
SELECT
    'ADM-DEMO-' || LPAD(gs::text, 3, '0'),
    p.patient_id,
    d.doctor_id,
    CURRENT_TIMESTAMP - ((gs * 2) || ' days')::interval,
    CASE WHEN gs % 2 = 0
         THEN CURRENT_TIMESTAMP - ((gs - 1) || ' days')::interval
         ELSE NULL
    END,
    'R-' || (100 + gs),
    'B-' || gs,
    (ARRAY['Observation','Planned procedure','Dehydration observation','Post-procedure care','Pain assessment','Routine monitoring'])[((gs - 1) % 6) + 1],
    CASE WHEN gs % 2 = 0 THEN 'Discharged' ELSE 'Admitted' END
FROM generate_series(1, 6) AS gs
JOIN public.patients p ON p.patient_code = 'PAT-' || LPAD((gs + 2)::text, 4, '0')
JOIN public.doctors d ON d.email = 'aarav.sharma.demo@example.test'
ON CONFLICT (admission_code) DO NOTHING;

-- 6. MEDICINES: synthetic inventory items, not treatment recommendations.
INSERT INTO public.medicines
    (medicine_code, medicine_name, category, manufacturer, batch_number, expiry_date,
     quantity_in_stock, reorder_level, purchase_price, selling_price)
VALUES
    ('MED-DEMO-001', 'Paracetamol 500 mg (Demo)', 'Analgesic', 'Demo Pharma', 'BATCH-D001', CURRENT_DATE + 300, 250, 50, 1.50, 2.50),
    ('MED-DEMO-002', 'Oral Rehydration Salts (Demo)', 'Electrolyte', 'Demo Pharma', 'BATCH-D002', CURRENT_DATE + 240, 18, 25, 8.00, 12.00),
    ('MED-DEMO-003', 'Vitamin C 500 mg (Demo)', 'Vitamin', 'Demo Pharma', 'BATCH-D003', CURRENT_DATE + 365, 120, 30, 3.00, 5.00),
    ('MED-DEMO-004', 'Antiseptic Solution (Demo)', 'Antiseptic', 'Demo Pharma', 'BATCH-D004', CURRENT_DATE + 180, 8, 15, 35.00, 48.00),
    ('MED-DEMO-005', 'Cetirizine 10 mg (Demo)', 'Antihistamine', 'Demo Pharma', 'BATCH-D005', CURRENT_DATE + 270, 90, 20, 2.00, 4.00),
    ('MED-DEMO-006', 'Cough Syrup (Demo)', 'Cough and cold', 'Demo Pharma', 'BATCH-D006', CURRENT_DATE + 150, 12, 20, 45.00, 65.00),
    ('MED-DEMO-007', 'Sterile Gauze Pack (Demo)', 'Dressing', 'Demo Supplies', 'BATCH-D007', CURRENT_DATE + 500, 75, 20, 10.00, 16.00),
    ('MED-DEMO-008', 'Saline 500 ml (Demo)', 'Medical supply', 'Demo Supplies', 'BATCH-D008', CURRENT_DATE + 210, 40, 15, 28.00, 40.00)
ON CONFLICT (medicine_code) DO NOTHING;

-- 7. PHARMACY TRANSACTIONS (demo stock history)
INSERT INTO public.pharmacy_transactions
    (medicine_id, transaction_type, quantity, unit_price, reference_number, notes)
SELECT m.medicine_id, x.transaction_type, x.quantity, x.unit_price, x.reference_number, x.notes
FROM (VALUES
    ('MED-DEMO-001', 'Purchase', 250, 1.50, 'STOCK-DEMO-001', 'Opening demo stock receipt'),
    ('MED-DEMO-002', 'Purchase', 18, 8.00, 'STOCK-DEMO-002', 'Opening demo stock receipt'),
    ('MED-DEMO-003', 'Purchase', 120, 3.00, 'STOCK-DEMO-003', 'Opening demo stock receipt'),
    ('MED-DEMO-004', 'Purchase', 8, 35.00, 'STOCK-DEMO-004', 'Opening demo stock receipt'),
    ('MED-DEMO-005', 'Purchase', 90, 2.00, 'STOCK-DEMO-005', 'Opening demo stock receipt'),
    ('MED-DEMO-006', 'Purchase', 12, 45.00, 'STOCK-DEMO-006', 'Opening demo stock receipt'),
    ('MED-DEMO-007', 'Purchase', 75, 10.00, 'STOCK-DEMO-007', 'Opening demo stock receipt'),
    ('MED-DEMO-008', 'Purchase', 40, 28.00, 'STOCK-DEMO-008', 'Opening demo stock receipt')
) AS x(medicine_code, transaction_type, quantity, unit_price, reference_number, notes)
JOIN public.medicines m ON m.medicine_code = x.medicine_code
WHERE NOT EXISTS (
    SELECT 1
    FROM public.pharmacy_transactions pt
    WHERE pt.reference_number = x.reference_number
);

-- 8. LAB TEST CATALOG
INSERT INTO public.lab_tests (test_code, test_name, category, description, price)
VALUES
    ('LAB-DEMO-001', 'Complete Blood Count (Demo)', 'Hematology', 'Synthetic demo test catalog item', 350.00),
    ('LAB-DEMO-002', 'Blood Glucose (Demo)', 'Biochemistry', 'Synthetic demo test catalog item', 150.00),
    ('LAB-DEMO-003', 'Lipid Profile (Demo)', 'Biochemistry', 'Synthetic demo test catalog item', 700.00),
    ('LAB-DEMO-004', 'Thyroid Profile (Demo)', 'Endocrinology', 'Synthetic demo test catalog item', 600.00),
    ('LAB-DEMO-005', 'Urine Routine (Demo)', 'Pathology', 'Synthetic demo test catalog item', 200.00),
    ('LAB-DEMO-006', 'Liver Function Test (Demo)', 'Biochemistry', 'Synthetic demo test catalog item', 650.00)
ON CONFLICT (test_code) DO NOTHING;

-- 9. LAB ORDERS: 12 demo orders. Results are intentionally illustrative only.
INSERT INTO public.lab_orders
    (order_code, patient_id, doctor_id, lab_test_id, ordered_at, status,
     result_text, result_unit, reference_range, result_date, notes)
SELECT
    'LABORD-DEMO-' || LPAD(gs::text, 4, '0'),
    p.patient_id,
    d.doctor_id,
    lt.lab_test_id,
    CURRENT_TIMESTAMP - ((gs % 10) || ' days')::interval,
    CASE WHEN gs % 3 = 0 THEN 'Completed'
         WHEN gs % 3 = 1 THEN 'Sample Collected'
         ELSE 'Ordered' END,
    CASE WHEN gs % 3 = 0 THEN 'DEMO RESULT - NOT FOR CLINICAL USE' ELSE NULL END,
    NULL,
    NULL,
    CASE WHEN gs % 3 = 0 THEN CURRENT_TIMESTAMP - ((gs % 8) || ' days')::interval ELSE NULL END,
    'Synthetic demonstration only; not a medical result'
FROM generate_series(1, 12) AS gs
JOIN public.patients p ON p.patient_code = 'PAT-' || LPAD(gs::text, 4, '0')
JOIN public.doctors d ON d.email = 'myra.joshi.demo@example.test'
JOIN public.lab_tests lt ON lt.test_code =
    'LAB-DEMO-' || LPAD((((gs - 1) % 6) + 1)::text, 3, '0')
ON CONFLICT (order_code) DO NOTHING;

-- 10. INVOICES: 15 demo invoices linked to appointments.
INSERT INTO public.invoices
    (invoice_number, patient_id, appointment_id, invoice_date, due_date,
     subtotal, discount_amount, tax_amount, total_amount, status, notes)
SELECT
    'INV-DEMO-' || LPAD(gs::text, 4, '0'),
    p.patient_id,
    a.appointment_id,
    CURRENT_TIMESTAMP - ((gs % 12) || ' days')::interval,
    CURRENT_DATE + ((gs % 7) || ' days')::interval,
    (500 + (gs * 50))::numeric(12,2),
    CASE WHEN gs % 5 = 0 THEN 50.00 ELSE 0.00 END,
    0.00,
    (500 + (gs * 50) - CASE WHEN gs % 5 = 0 THEN 50 ELSE 0 END)::numeric(12,2),
    CASE WHEN gs % 3 = 0 THEN 'Paid'
         WHEN gs % 3 = 1 THEN 'Unpaid'
         ELSE 'Partially Paid' END,
    'Synthetic demo invoice; verify totals through application logic'
FROM generate_series(1, 15) AS gs
JOIN public.patients p ON p.patient_code = 'PAT-' || LPAD(gs::text, 4, '0')
JOIN public.appointments a ON a.appointment_code = 'APT-DEMO-' || LPAD(gs::text, 4, '0')
ON CONFLICT (invoice_number) DO NOTHING;

-- 11. INVOICE ITEMS: one consultation item per demo invoice.
INSERT INTO public.invoice_items
    (invoice_id, item_type, description, quantity, unit_price, discount_amount, line_total)
SELECT
    i.invoice_id,
    'Consultation',
    'Consultation service (demo)',
    1,
    i.subtotal,
    i.discount_amount,
    i.subtotal - i.discount_amount
FROM public.invoices i
WHERE i.invoice_number LIKE 'INV-DEMO-%'
  AND NOT EXISTS (
      SELECT 1 FROM public.invoice_items ii WHERE ii.invoice_id = i.invoice_id
  );

-- 12. PAYMENTS: completed payments only for selected demo invoices.
INSERT INTO public.payments
    (payment_reference, invoice_id, amount, payment_method, payment_status, notes)
SELECT
    'PAY-DEMO-' || LPAD(gs::text, 4, '0'),
    i.invoice_id,
    CASE
        WHEN i.status = 'Paid' THEN i.total_amount
        ELSE ROUND(i.total_amount / 2, 2)
    END,
    (ARRAY['Cash','Card','UPI','Bank Transfer'])[((gs - 1) % 4) + 1],
    'Completed',
    'Synthetic demonstration payment'
FROM generate_series(1, 15) AS gs
JOIN public.invoices i ON i.invoice_number = 'INV-DEMO-' || LPAD(gs::text, 4, '0')
WHERE i.status IN ('Paid', 'Partially Paid')
ON CONFLICT (payment_reference) DO NOTHING;

COMMIT;

-- ============================================================
-- VERIFICATION QUERIES
-- Run after the script to check record counts.
-- ============================================================

SELECT 'departments' AS table_name, COUNT(*) AS record_count FROM public.departments
UNION ALL SELECT 'doctors', COUNT(*) FROM public.doctors
UNION ALL SELECT 'patients', COUNT(*) FROM public.patients
UNION ALL SELECT 'appointments', COUNT(*) FROM public.appointments
UNION ALL SELECT 'admissions', COUNT(*) FROM public.admissions
UNION ALL SELECT 'medicines', COUNT(*) FROM public.medicines
UNION ALL SELECT 'pharmacy_transactions', COUNT(*) FROM public.pharmacy_transactions
UNION ALL SELECT 'lab_tests', COUNT(*) FROM public.lab_tests
UNION ALL SELECT 'lab_orders', COUNT(*) FROM public.lab_orders
UNION ALL SELECT 'invoices', COUNT(*) FROM public.invoices
UNION ALL SELECT 'invoice_items', COUNT(*) FROM public.invoice_items
UNION ALL SELECT 'payments', COUNT(*) FROM public.payments
ORDER BY table_name;

-- Useful report checks:
-- SELECT * FROM public.vw_appointment_details ORDER BY appointment_date DESC;
-- SELECT * FROM public.vw_low_stock_medicines ORDER BY quantity_in_stock;
-- SELECT * FROM public.vw_invoice_payment_summary ORDER BY invoice_date DESC;
