-- 1. Primary Key, Unique और Foreign Key Constraints
SELECT
    tc.constraint_type,
    tc.constraint_name,
    kcu.column_name
FROM information_schema.table_constraints AS tc
LEFT JOIN information_schema.key_column_usage AS kcu
    ON tc.constraint_name = kcu.constraint_name
    AND tc.constraint_schema = kcu.constraint_schema
WHERE tc.table_schema = 'public'
  AND tc.table_name = 'patients'
ORDER BY tc.constraint_type, kcu.column_name;

-- 2. Column Defaults
SELECT
    column_name,
    column_default,
    is_nullable
FROM information_schema.columns
WHERE table_schema = 'public'
  AND table_name = 'patients'
ORDER BY ordinal_position;

-- 3. वर्तमान Patient Records की संख्या
SELECT
    COUNT(*) AS total_patients,
    COUNT(*) FILTER (WHERE is_active = TRUE) AS active_patients,
    COUNT(*) FILTER (WHERE is_active = FALSE) AS inactive_patients
FROM public.patients;