-- ============================================================
-- MediCore Hospital Management System
-- PostgreSQL 18 - Database Schema, Indexes and Reporting Views
--
-- IMPORTANT:
-- 1. In pgAdmin, first open the Query Tool for:
--       hospital_management_db
-- 2. Open this file in the Query Tool (or paste its contents).
-- 3. Execute the script.
-- 4. This script creates tables if they do not already exist.
--    It does NOT modify the structure of existing tables.
-- 5. Run on a development/empty project database first.
-- ============================================================

BEGIN;

-- 1. DEPARTMENTS
CREATE TABLE IF NOT EXISTS public.departments (
    department_id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    department_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 2. USERS
CREATE TABLE IF NOT EXISTS public.users (
    user_id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    full_name VARCHAR(120) NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(150) UNIQUE,
    password_hash TEXT NOT NULL,
    role VARCHAR(30) NOT NULL
        CHECK (role IN (
            'admin', 'doctor', 'receptionist', 'nurse',
            'accountant', 'pharmacist', 'lab_technician'
        )),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 3. DOCTORS
CREATE TABLE IF NOT EXISTS public.doctors (
    doctor_id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id INTEGER UNIQUE REFERENCES public.users(user_id) ON DELETE SET NULL,
    department_id INTEGER REFERENCES public.departments(department_id) ON DELETE RESTRICT,
    doctor_name VARCHAR(120) NOT NULL,
    specialization VARCHAR(100) NOT NULL,
    qualification VARCHAR(150),
    phone VARCHAR(20),
    email VARCHAR(150) UNIQUE,
    consultation_fee NUMERIC(10,2) NOT NULL DEFAULT 0 CHECK (consultation_fee >= 0),
    available_from TIME,
    available_to TIME,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CHECK (
        available_from IS NULL
        OR available_to IS NULL
        OR available_from < available_to
    )
);

-- 4. PATIENTS
CREATE TABLE IF NOT EXISTS public.patients (
    patient_id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    patient_code VARCHAR(20) NOT NULL UNIQUE,
    first_name VARCHAR(80) NOT NULL,
    last_name VARCHAR(80),
    date_of_birth DATE,
    gender VARCHAR(20)
        CHECK (gender IN ('Male', 'Female', 'Other', 'Prefer not to say')),
    blood_group VARCHAR(5)
        CHECK (
            blood_group IS NULL
            OR blood_group IN ('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-')
        ),
    phone VARCHAR(20),
    email VARCHAR(150),
    address TEXT,
    emergency_contact_name VARCHAR(120),
    emergency_contact_phone VARCHAR(20),
    allergies TEXT,
    registration_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    CHECK (date_of_birth IS NULL OR date_of_birth <= CURRENT_DATE)
);

-- 5. APPOINTMENTS
CREATE TABLE IF NOT EXISTS public.appointments (
    appointment_id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    appointment_code VARCHAR(30) NOT NULL UNIQUE,
    patient_id INTEGER NOT NULL REFERENCES public.patients(patient_id) ON DELETE RESTRICT,
    doctor_id INTEGER NOT NULL REFERENCES public.doctors(doctor_id) ON DELETE RESTRICT,
    appointment_date TIMESTAMP NOT NULL,
    reason TEXT,
    status VARCHAR(20) NOT NULL DEFAULT 'Scheduled'
        CHECK (status IN ('Scheduled', 'Confirmed', 'Completed', 'Cancelled', 'No Show')),
    notes TEXT,
    created_by INTEGER REFERENCES public.users(user_id) ON DELETE SET NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 6. ADMISSIONS
CREATE TABLE IF NOT EXISTS public.admissions (
    admission_id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    admission_code VARCHAR(30) NOT NULL UNIQUE,
    patient_id INTEGER NOT NULL REFERENCES public.patients(patient_id) ON DELETE RESTRICT,
    doctor_id INTEGER REFERENCES public.doctors(doctor_id) ON DELETE SET NULL,
    admission_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    discharge_date TIMESTAMP,
    room_number VARCHAR(20),
    bed_number VARCHAR(20),
    admission_reason TEXT,
    status VARCHAR(20) NOT NULL DEFAULT 'Admitted'
        CHECK (status IN ('Admitted', 'Discharged', 'Transferred')),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CHECK (discharge_date IS NULL OR discharge_date >= admission_date)
);

-- 7. MEDICINES
CREATE TABLE IF NOT EXISTS public.medicines (
    medicine_id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    medicine_code VARCHAR(30) NOT NULL UNIQUE,
    medicine_name VARCHAR(150) NOT NULL,
    category VARCHAR(80),
    manufacturer VARCHAR(120),
    batch_number VARCHAR(80),
    expiry_date DATE,
    quantity_in_stock INTEGER NOT NULL DEFAULT 0 CHECK (quantity_in_stock >= 0),
    reorder_level INTEGER NOT NULL DEFAULT 10 CHECK (reorder_level >= 0),
    purchase_price NUMERIC(10,2) NOT NULL DEFAULT 0 CHECK (purchase_price >= 0),
    selling_price NUMERIC(10,2) NOT NULL DEFAULT 0 CHECK (selling_price >= 0),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 8. PHARMACY TRANSACTIONS
CREATE TABLE IF NOT EXISTS public.pharmacy_transactions (
    transaction_id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    medicine_id INTEGER NOT NULL REFERENCES public.medicines(medicine_id) ON DELETE RESTRICT,
    transaction_type VARCHAR(20) NOT NULL
        CHECK (transaction_type IN ('Purchase', 'Sale', 'Return', 'Adjustment', 'Expired')),
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    unit_price NUMERIC(10,2) NOT NULL CHECK (unit_price >= 0),
    transaction_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    reference_number VARCHAR(50),
    notes TEXT,
    created_by INTEGER REFERENCES public.users(user_id) ON DELETE SET NULL
);

-- 9. LAB TEST CATALOG
CREATE TABLE IF NOT EXISTS public.lab_tests (
    lab_test_id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    test_code VARCHAR(30) NOT NULL UNIQUE,
    test_name VARCHAR(150) NOT NULL UNIQUE,
    category VARCHAR(80),
    description TEXT,
    price NUMERIC(10,2) NOT NULL DEFAULT 0 CHECK (price >= 0),
    is_active BOOLEAN NOT NULL DEFAULT TRUE
);

-- 10. LAB ORDERS
CREATE TABLE IF NOT EXISTS public.lab_orders (
    lab_order_id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    order_code VARCHAR(30) NOT NULL UNIQUE,
    patient_id INTEGER NOT NULL REFERENCES public.patients(patient_id) ON DELETE RESTRICT,
    doctor_id INTEGER REFERENCES public.doctors(doctor_id) ON DELETE SET NULL,
    lab_test_id INTEGER NOT NULL REFERENCES public.lab_tests(lab_test_id) ON DELETE RESTRICT,
    ordered_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) NOT NULL DEFAULT 'Ordered'
        CHECK (status IN ('Ordered', 'Sample Collected', 'In Progress', 'Completed', 'Cancelled')),
    result_text TEXT,
    result_unit VARCHAR(40),
    reference_range VARCHAR(100),
    result_date TIMESTAMP,
    notes TEXT
);

-- 11. INVOICES
CREATE TABLE IF NOT EXISTS public.invoices (
    invoice_id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    invoice_number VARCHAR(30) NOT NULL UNIQUE,
    patient_id INTEGER NOT NULL REFERENCES public.patients(patient_id) ON DELETE RESTRICT,
    appointment_id INTEGER REFERENCES public.appointments(appointment_id) ON DELETE SET NULL,
    admission_id INTEGER REFERENCES public.admissions(admission_id) ON DELETE SET NULL,
    invoice_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    due_date DATE,
    subtotal NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (subtotal >= 0),
    discount_amount NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (discount_amount >= 0),
    tax_amount NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (tax_amount >= 0),
    total_amount NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (total_amount >= 0),
    status VARCHAR(20) NOT NULL DEFAULT 'Unpaid'
        CHECK (status IN ('Unpaid', 'Partially Paid', 'Paid', 'Cancelled')),
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CHECK (discount_amount <= subtotal)
);

-- 12. INVOICE ITEMS
CREATE TABLE IF NOT EXISTS public.invoice_items (
    invoice_item_id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    invoice_id INTEGER NOT NULL REFERENCES public.invoices(invoice_id) ON DELETE RESTRICT,
    item_type VARCHAR(30) NOT NULL
        CHECK (item_type IN ('Consultation', 'Medicine', 'Laboratory', 'Room', 'Procedure', 'Other')),
    description VARCHAR(200) NOT NULL,
    medicine_id INTEGER REFERENCES public.medicines(medicine_id) ON DELETE RESTRICT,
    lab_order_id INTEGER REFERENCES public.lab_orders(lab_order_id) ON DELETE RESTRICT,
    quantity INTEGER NOT NULL DEFAULT 1 CHECK (quantity > 0),
    unit_price NUMERIC(10,2) NOT NULL CHECK (unit_price >= 0),
    discount_amount NUMERIC(10,2) NOT NULL DEFAULT 0 CHECK (discount_amount >= 0),
    line_total NUMERIC(12,2) NOT NULL CHECK (line_total >= 0),
    CHECK (discount_amount <= quantity * unit_price)
);

-- 13. PAYMENTS
CREATE TABLE IF NOT EXISTS public.payments (
    payment_id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    payment_reference VARCHAR(40) NOT NULL UNIQUE,
    invoice_id INTEGER NOT NULL REFERENCES public.invoices(invoice_id) ON DELETE RESTRICT,
    amount NUMERIC(12,2) NOT NULL CHECK (amount > 0),
    payment_method VARCHAR(30) NOT NULL
        CHECK (payment_method IN ('Cash', 'Card', 'UPI', 'Bank Transfer', 'Insurance', 'Other')),
    payment_status VARCHAR(20) NOT NULL DEFAULT 'Completed'
        CHECK (payment_status IN ('Pending', 'Completed', 'Failed', 'Refunded')),
    transaction_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    transaction_id VARCHAR(100),
    notes TEXT,
    created_by INTEGER REFERENCES public.users(user_id) ON DELETE SET NULL
);

-- INDEXES
CREATE INDEX IF NOT EXISTS idx_patients_name
    ON public.patients(first_name, last_name);
CREATE INDEX IF NOT EXISTS idx_patients_phone
    ON public.patients(phone);
CREATE INDEX IF NOT EXISTS idx_appointments_patient
    ON public.appointments(patient_id);
CREATE INDEX IF NOT EXISTS idx_appointments_doctor_date
    ON public.appointments(doctor_id, appointment_date);
CREATE INDEX IF NOT EXISTS idx_appointments_status
    ON public.appointments(status);
CREATE INDEX IF NOT EXISTS idx_admissions_patient
    ON public.admissions(patient_id);
CREATE INDEX IF NOT EXISTS idx_admissions_status
    ON public.admissions(status);
CREATE INDEX IF NOT EXISTS idx_medicines_name
    ON public.medicines(medicine_name);
CREATE INDEX IF NOT EXISTS idx_medicines_expiry
    ON public.medicines(expiry_date);
CREATE INDEX IF NOT EXISTS idx_lab_orders_patient
    ON public.lab_orders(patient_id);
CREATE INDEX IF NOT EXISTS idx_lab_orders_status
    ON public.lab_orders(status);
CREATE INDEX IF NOT EXISTS idx_invoices_patient
    ON public.invoices(patient_id);
CREATE INDEX IF NOT EXISTS idx_invoices_date
    ON public.invoices(invoice_date);
CREATE INDEX IF NOT EXISTS idx_invoices_status
    ON public.invoices(status);
CREATE INDEX IF NOT EXISTS idx_payments_invoice
    ON public.payments(invoice_id);
CREATE INDEX IF NOT EXISTS idx_payments_date
    ON public.payments(transaction_date);

-- REPORTING VIEW: APPOINTMENT DETAILS
CREATE OR REPLACE VIEW public.vw_appointment_details AS
SELECT
    a.appointment_id,
    a.appointment_code,
    p.patient_code,
    TRIM(p.first_name || ' ' || COALESCE(p.last_name, '')) AS patient_name,
    d.doctor_name,
    dep.department_name,
    a.appointment_date,
    a.status
FROM public.appointments AS a
JOIN public.patients AS p ON p.patient_id = a.patient_id
JOIN public.doctors AS d ON d.doctor_id = a.doctor_id
LEFT JOIN public.departments AS dep ON dep.department_id = d.department_id;

-- REPORTING VIEW: LOW-STOCK MEDICINES
CREATE OR REPLACE VIEW public.vw_low_stock_medicines AS
SELECT
    medicine_id,
    medicine_code,
    medicine_name,
    quantity_in_stock,
    reorder_level,
    expiry_date
FROM public.medicines
WHERE quantity_in_stock <= reorder_level
  AND is_active = TRUE;

-- REPORTING VIEW: INVOICE PAYMENT SUMMARY
CREATE OR REPLACE VIEW public.vw_invoice_payment_summary AS
SELECT
    i.invoice_id,
    i.invoice_number,
    i.patient_id,
    i.invoice_date,
    i.total_amount,
    COALESCE(
        SUM(p.amount) FILTER (WHERE p.payment_status = 'Completed'),
        0
    ) AS paid_amount,
    GREATEST(
        i.total_amount - COALESCE(
            SUM(p.amount) FILTER (WHERE p.payment_status = 'Completed'),
            0
        ),
        0
    ) AS outstanding_amount
FROM public.invoices AS i
LEFT JOIN public.payments AS p ON p.invoice_id = i.invoice_id
GROUP BY
    i.invoice_id,
    i.invoice_number,
    i.patient_id,
    i.invoice_date,
    i.total_amount;

COMMIT;

-- ============================================================
-- VERIFICATION QUERIES
-- Run these after the schema script completes.
-- ============================================================

-- List all tables:
-- SELECT table_name
-- FROM information_schema.tables
-- WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
-- ORDER BY table_name;

-- List reporting views:
-- SELECT table_name
-- FROM information_schema.views
-- WHERE table_schema = 'public'
-- ORDER BY table_name;

-- Expected: 13 base tables and 3 reporting views.
