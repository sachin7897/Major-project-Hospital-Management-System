-- ============================================================
-- MediCore Hospital Management System
-- Database Verification and Reporting Queries
-- Run this AFTER schema and synthetic dataset scripts.
-- Database: hospital_management_db
-- ============================================================

-- 1. Check record counts in the main tables
SELECT 'departments' AS table_name, COUNT(*) AS record_count FROM public.departments
UNION ALL SELECT 'users', COUNT(*) FROM public.users
UNION ALL SELECT 'doctors', COUNT(*) FROM public.doctors
UNION ALL SELECT 'patients', COUNT(*) FROM public.patients
UNION ALL SELECT 'appointments', COUNT(*) FROM public.appointments
UNION ALL SELECT 'admissions', COUNT(*) FROM public.admissions
UNION ALL SELECT 'medicines', COUNT(*) FROM public.medicines
UNION ALL SELECT 'pharmacy_transactions', COUNT(*) FROM public.pharmacy_transactions
UNION ALL SELECT 'lab_tests', COUNT(*) FROM public.lab_tests
UNION ALL SELECT 'lab_orders', COUNT(*) FROM public.lab_orders
UNION ALL SELECT 'invoices', COUNT(*) FROM public.invoices
UNION ALL SELECT 'invoice_items', COUNT(*) FROM public.invoice_items
UNION ALL SELECT 'payments', COUNT(*) FROM public.payments
ORDER BY table_name;


-- 2. Dashboard summary cards
SELECT
    (SELECT COUNT(*) FROM public.patients WHERE is_active = TRUE) AS active_patients,
    (SELECT COUNT(*) FROM public.doctors WHERE is_active = TRUE) AS active_doctors,
    (SELECT COUNT(*) FROM public.appointments
        WHERE appointment_date::date = CURRENT_DATE
          AND status NOT IN ('Cancelled', 'No Show')) AS appointments_today,
    (SELECT COUNT(*) FROM public.admissions WHERE status = 'Admitted') AS current_admissions,
    (SELECT COUNT(*) FROM public.invoices WHERE status IN ('Unpaid', 'Partially Paid')) AS unpaid_or_partial_invoices,
    (SELECT COUNT(*) FROM public.medicines
        WHERE is_active = TRUE AND quantity_in_stock <= reorder_level) AS low_stock_medicines;


-- 3. Appointment details (uses reporting view)
SELECT *
FROM public.vw_appointment_details
ORDER BY appointment_date DESC
LIMIT 50;


-- 4. Appointment counts by status
SELECT status, COUNT(*) AS total_appointments
FROM public.appointments
GROUP BY status
ORDER BY total_appointments DESC;


-- 5. Appointments by doctor
SELECT
    d.doctor_name,
    dep.department_name,
    COUNT(a.appointment_id) AS total_appointments
FROM public.doctors d
LEFT JOIN public.departments dep ON dep.department_id = d.department_id
LEFT JOIN public.appointments a ON a.doctor_id = d.doctor_id
GROUP BY d.doctor_id, d.doctor_name, dep.department_name
ORDER BY total_appointments DESC, d.doctor_name;


-- 6. Today's appointments
SELECT *
FROM public.vw_appointment_details
WHERE appointment_date::date = CURRENT_DATE
ORDER BY appointment_date;


-- 7. Revenue summary (invoice totals, not necessarily cash collected)
SELECT
    COALESCE(SUM(total_amount) FILTER (WHERE status <> 'Cancelled'), 0) AS total_invoiced,
    COALESCE(SUM(total_amount) FILTER (
        WHERE invoice_date >= date_trunc('month', CURRENT_DATE)
          AND status <> 'Cancelled'
    ), 0) AS invoiced_this_month
FROM public.invoices;


-- 8. Actual completed payments collected
SELECT
    COALESCE(SUM(amount) FILTER (WHERE payment_status = 'Completed'), 0) AS total_payments_collected,
    COALESCE(SUM(amount) FILTER (
        WHERE payment_status = 'Completed'
          AND transaction_date >= date_trunc('month', CURRENT_DATE)
    ), 0) AS collected_this_month
FROM public.payments;


-- 9. Pending / outstanding invoice balances
SELECT
    i.invoice_number,
    TRIM(p.first_name || ' ' || COALESCE(p.last_name, '')) AS patient_name,
    i.invoice_date,
    i.total_amount,
    s.paid_amount,
    s.outstanding_amount,
    i.status
FROM public.invoices i
JOIN public.patients p ON p.patient_id = i.patient_id
JOIN public.vw_invoice_payment_summary s ON s.invoice_id = i.invoice_id
WHERE i.status <> 'Cancelled'
  AND s.outstanding_amount > 0
ORDER BY s.outstanding_amount DESC, i.invoice_date DESC;


-- 10. Low-stock medicines
SELECT *
FROM public.vw_low_stock_medicines
ORDER BY quantity_in_stock ASC, medicine_name;


-- 11. Medicines nearing expiry in the next 90 days
SELECT medicine_code, medicine_name, batch_number, expiry_date, quantity_in_stock
FROM public.medicines
WHERE is_active = TRUE
  AND expiry_date BETWEEN CURRENT_DATE AND CURRENT_DATE + 90
ORDER BY expiry_date;


-- 12. Current inpatients
SELECT
    a.admission_code,
    TRIM(p.first_name || ' ' || COALESCE(p.last_name, '')) AS patient_name,
    d.doctor_name,
    a.room_number,
    a.bed_number,
    a.admission_date,
    a.admission_reason
FROM public.admissions a
JOIN public.patients p ON p.patient_id = a.patient_id
LEFT JOIN public.doctors d ON d.doctor_id = a.doctor_id
WHERE a.status = 'Admitted'
ORDER BY a.admission_date;


-- 13. Laboratory workload by status
SELECT status, COUNT(*) AS total_orders
FROM public.lab_orders
GROUP BY status
ORDER BY total_orders DESC;


-- 14. Recent lab orders
SELECT
    lo.order_code,
    TRIM(p.first_name || ' ' || COALESCE(p.last_name, '')) AS patient_name,
    lt.test_name,
    lo.ordered_at,
    lo.status,
    lo.result_text
FROM public.lab_orders lo
JOIN public.patients p ON p.patient_id = lo.patient_id
JOIN public.lab_tests lt ON lt.lab_test_id = lo.lab_test_id
ORDER BY lo.ordered_at DESC
LIMIT 30;


-- 15. Database relationship sanity check: appointments with missing patient/doctor
-- With valid foreign keys, this query should return zero.
SELECT COUNT(*) AS appointments_with_missing_relationships
FROM public.appointments a
LEFT JOIN public.patients p ON p.patient_id = a.patient_id
LEFT JOIN public.doctors d ON d.doctor_id = a.doctor_id
WHERE p.patient_id IS NULL OR d.doctor_id IS NULL;


-- 16. View list
SELECT table_name AS view_name
FROM information_schema.views
WHERE table_schema = 'public'
  AND table_name LIKE 'vw_%'
ORDER BY table_name;
